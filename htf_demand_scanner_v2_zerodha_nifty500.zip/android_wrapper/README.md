# Android packaging plan

This prototype is a Streamlit web app. For Android use:
1. Deploy the web app behind HTTPS and authentication.
2. Create a Flutter app with a WebView pointing to your deployed URL, or rebuild the dashboard in Flutter and call a secure backend API.
3. Keep Kite API secret and access tokens on the backend only; never embed them in an APK.
4. Configure Android notification permission and Firebase Cloud Messaging if native push alerts are required.
5. Build/sign APK or AAB using Android Studio/Flutter tooling.

This folder is documentation only; it is not a compiled APK.
