from datetime import datetime, timedelta
import pandas as pd
from kiteconnect import KiteConnect

def connect_kite(api_key, access_token):
    kite = KiteConnect(api_key=api_key)
    kite.set_access_token(access_token)
    # Validate credentials without requesting account-sensitive information.
    kite.profile()
    return kite

def load_nse_instruments(kite):
    instruments = pd.DataFrame(kite.instruments("NSE"))
    if instruments.empty:
        raise RuntimeError("NSE instrument master is empty")
    return dict(zip(instruments["tradingsymbol"].astype(str).str.upper(), instruments["instrument_token"]))

def fetch_daily_history(kite, token, lookback_days=750):
    end = datetime.now()
    start = end - timedelta(days=lookback_days)
    rows = kite.historical_data(token, start, end, "day", continuous=False, oi=False)
    if not rows:
        raise ValueError("No daily candles returned")
    return pd.DataFrame(rows)

def fetch_ltp_batch(kite, symbols):
    result = {}
    # Kite quote LTP supports batched keys; chunk defensively.
    for i in range(0, len(symbols), 200):
        chunk = symbols[i:i+200]
        keys = [f"NSE:{s}" for s in chunk]
        quotes = kite.ltp(keys)
        for key, val in quotes.items():
            result[key.split(":",1)[1].upper()] = float(val["last_price"])
    return result
