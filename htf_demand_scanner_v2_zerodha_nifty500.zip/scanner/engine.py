import pandas as pd
import numpy as np

def normalize(df):
    x = df.copy()
    aliases = {"Date":"date","Open":"open","High":"high","Low":"low","Close":"close","Volume":"volume"}
    x = x.rename(columns={k:v for k,v in aliases.items() if k in x.columns})
    for c in ("date","open","high","low","close"):
        if c not in x.columns:
            raise ValueError(f"Missing required column: {c}")
    x["date"] = pd.to_datetime(x["date"])
    for c in ("open","high","low","close","volume"):
        if c in x.columns:
            x[c] = pd.to_numeric(x[c], errors="coerce")
    return x.dropna(subset=["date","open","high","low","close"]).sort_values("date").reset_index(drop=True)

def to_timeframe(df, timeframe):
    x = normalize(df)
    if timeframe == "Weekly":
        agg = {"open":"first","high":"max","low":"min","close":"last"}
        if "volume" in x.columns:
            agg["volume"] = "sum"
        x = x.set_index("date").resample("W-FRI").agg(agg).dropna().reset_index()
    return x

def build_zones(symbol, candles, timeframe="Daily", max_age_bars=40):
    df = to_timeframe(candles, timeframe)
    if len(df) < 15:
        return []
    o,h,l,c = [df[k].to_numpy(float) for k in ("open","high","low","close")]
    vol = df["volume"].to_numpy(float) if "volume" in df.columns else None
    zones = []
    start_idx = max(2, len(df) - max_age_bars - 6)
    # Base length 2-4 bars; demand bounds from base wick extremes.
    for base_start in range(start_idx, len(df)-4):
        for base_len in (2,3,4):
            base_end = base_start + base_len - 1
            depart_end = min(len(df)-1, base_end + 3)
            if base_end + 1 >= len(df):
                continue
            base_low = float(np.min(l[base_start:base_end+1]))
            base_high = float(np.max(h[base_start:base_end+1]))
            if base_low <= 0 or base_high <= base_low:
                continue
            width_pct = (base_high-base_low)/base_low*100
            if width_pct > 8:
                continue
            departure_close = float(np.max(c[base_end+1:depart_end+1]))
            rally_pct = (departure_close-base_high)/base_high*100
            first_depart_body = (c[base_end+1]-o[base_end+1])/max(o[base_end+1],1e-9)*100
            if rally_pct < 2.5 and first_depart_body < 1.5:
                continue
            pre_move = (c[base_start-1]-c[max(0,base_start-3)])/max(c[max(0,base_start-3)],1e-9)*100
            pattern = "DBR" if pre_move < -1.5 else "RBR"
            age = len(df)-1-base_end
            if age > max_age_bars:
                continue
            # Reject a zone that has already been cleanly broken by a later candle close.
            post_lows = l[base_end+1:]
            post_closes = c[base_end+1:]
            broken = bool(np.any(post_closes < base_low))
            if broken:
                continue
            # Freshness: count how many later candles traded into zone.
            later_touch = int(np.sum((l[base_end+1:] <= base_high) & (h[base_end+1:] >= base_low)))
            freshness_score = max(0, 25 - age*0.5 - later_touch*8)
            departure_score = min(35, max(0, rally_pct*3.5))
            base_score = max(0, 20 - width_pct*2.5)
            volume_score = 10
            if vol is not None and len(vol) > 10:
                before = np.nanmean(vol[max(0,base_start-15):base_start])
                after = np.nanmean(vol[base_end+1:depart_end+1])
                if np.isfinite(before) and before > 0 and np.isfinite(after):
                    volume_score = min(10, max(0, after/before*5))
            structure_score = 10 if pattern == "DBR" else 7
            score = int(round(min(100, freshness_score+departure_score+base_score+volume_score+structure_score)))
            zones.append({
                "symbol": str(symbol).upper(), "timeframe": timeframe, "pattern": pattern,
                "zone_low": round(base_low,2), "zone_high": round(base_high,2),
                "score": score, "zone_date": str(df.loc[base_start,"date"].date()),
                "zone_age_bars": int(age), "base_width_pct": round(width_pct,2),
                "departure_pct": round(rally_pct,2), "later_touches": later_touch,
                "rule_note": "Heuristic candidate; manually verify"
            })
    # One best/latest candidate per symbol/timeframe is selected by caller.
    zones.sort(key=lambda z: (z["score"], -z["zone_age_bars"]), reverse=True)
    return zones[:10]

def evaluate_zone(zone_low, zone_high, price, near_pct=1.0):
    if price is None or pd.isna(price):
        return "PRICE UNAVAILABLE"
    price, lo, hi = float(price), float(zone_low), float(zone_high)
    if price < lo:
        return "ZONE BROKEN"
    if lo <= price <= hi:
        return "ENTERED ZONE"
    dist = (price-hi)/hi*100 if price > hi else (lo-price)/lo*100
    if price > hi and dist <= near_pct:
        return "NEAR ZONE"
    return "ABOVE ZONE" if price > hi else "ZONE BROKEN"
