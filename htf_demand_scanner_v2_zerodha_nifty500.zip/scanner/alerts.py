import sqlite3, os, requests
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "alerts.sqlite3")

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT, symbol TEXT, timeframe TEXT, event TEXT,
            price REAL, zone_low REAL, zone_high REAL, score INTEGER, message TEXT
        )""")
        conn.commit()

def log_alert(symbol, timeframe, event, price, zone_low, zone_high, score, message):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("INSERT INTO alerts(timestamp,symbol,timeframe,event,price,zone_low,zone_high,score,message) VALUES(?,?,?,?,?,?,?,?,?)",
                     (datetime.now().isoformat(timespec="seconds"), symbol, timeframe, event,
                      float(price), float(zone_low), float(zone_high), int(score), message))
        conn.commit()

def get_alerts(limit=250):
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute("SELECT timestamp,symbol,timeframe,event,price,zone_low,zone_high,score,message FROM alerts ORDER BY id DESC LIMIT ?", (int(limit),))
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols,row)) for row in cur.fetchall()]

def send_telegram(bot_token, chat_id, message):
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    r = requests.post(url, json={"chat_id": chat_id, "text": message}, timeout=10)
    r.raise_for_status()
    return r.json()
