import os, time, json, sqlite3
from datetime import datetime
import pandas as pd
import streamlit as st
from streamlit_autorefresh import st_autorefresh
from scanner.engine import build_zones, evaluate_zone
from scanner.kite_adapter import connect_kite, load_nse_instruments, fetch_daily_history, fetch_ltp_batch
from scanner.alerts import init_db, log_alert, get_alerts, send_telegram

st.set_page_config(page_title="HTF Demand Scanner", page_icon="📈", layout="wide")
init_db()
st.title("📈 Higher Timeframe Demand Zone Scanner")
st.caption("Zerodha Kite Connect • NSE / Nifty 500 • Daily + Weekly • DBR / RBR")

with st.sidebar:
    st.header("Connection")
    api_key = st.text_input("Kite API key", type="password")
    access_token = st.text_input("Kite access token (session)", type="password")
    st.caption("Access token ko source code mein save/share na karein. Zerodha API session token aam taur par daily renew karna hota hai.")
    st.divider()
    st.header("Scan rules")
    min_score = st.slider("Minimum zone score", 0, 100, 65)
    near_pct = st.slider("Near-zone distance (%)", 0.1, 5.0, 1.0, 0.1)
    freshness_days = st.slider("Fresh zone age limit (bars)", 5, 120, 40)
    timeframes = st.multiselect("Timeframes", ["Daily", "Weekly"], default=["Daily", "Weekly"])
    st.divider()
    st.header("Universe")
    symbols_file = st.file_uploader("Nifty 500 symbols CSV (column: symbol)", type=["csv"])
    use_demo = st.checkbox("Use synthetic demo data (not live)", value=False)
    st.divider()
    st.header("Optional Telegram alerts")
    tg_token = st.text_input("Telegram bot token", type="password")
    tg_chat = st.text_input("Telegram chat ID")
    st.caption("Telegram credentials optional hain. Bot ko pehle start karke chat ID set karein.")

if symbols_file:
    uni = pd.read_csv(symbols_file)
    symbol_col = "symbol" if "symbol" in uni.columns else ("Symbol" if "Symbol" in uni.columns else None)
    if symbol_col is None:
        st.error("CSV mein `symbol` ya `Symbol` column hona chahiye.")
        st.stop()
    symbols = uni[symbol_col].dropna().astype(str).str.strip().str.upper().drop_duplicates().tolist()
    st.info(f"Uploaded universe: {len(symbols)} symbols")
else:
    bundled = os.path.join(os.path.dirname(__file__), "data", "nifty500_symbols.csv")
    uni = pd.read_csv(bundled)
    symbols = uni["symbol"].dropna().astype(str).str.strip().str.upper().drop_duplicates().tolist()
    st.info(f"Bundled Nifty 500 universe: {len(symbols)} symbols. Upload a newer CSV to update the list.")

tabs = st.tabs(["Live Monitor", "Zone Scan", "Alert History", "Setup Guide"])

with tabs[0]:
    st.subheader("Live monitor")
    refresh_seconds = st.selectbox("LTP refresh interval", [15, 30, 60, 120], index=1)
    auto_refresh = st.checkbox("Auto-refresh page", value=False)
    if auto_refresh:
        st_autorefresh(interval=refresh_seconds * 1000, key="live_refresh")
    if "zones" not in st.session_state:
        st.session_state.zones = []
    if "last_ltp" not in st.session_state:
        st.session_state.last_ltp = {}
    if "last_event" not in st.session_state:
        st.session_state.last_event = {}

    if st.button("🔄 Refresh prices & check alerts", type="primary", key="refresh_prices"):
        if not st.session_state.zones:
            st.info("Pehle Zone Scan tab mein scan run karein.")
        elif not (api_key and access_token):
            st.error("Live prices ke liye Kite API key aur access token chahiye.")
        else:
            try:
                kite = connect_kite(api_key, access_token)
                symbols_to_quote = sorted(set(z["symbol"] for z in st.session_state.zones))
                prices = fetch_ltp_batch(kite, symbols_to_quote)
                st.session_state.last_ltp = prices
                new_events = []
                for z in st.session_state.zones:
                    px = prices.get(z["symbol"])
                    if px is None:
                        continue
                    event = evaluate_zone(z["zone_low"], z["zone_high"], px, near_pct)
                    key = f'{z["symbol"]}|{z["timeframe"]}|{z["zone_date"]}'
                    previous = st.session_state.last_event.get(key)
                    if event in ("NEAR ZONE", "ENTERED ZONE", "ZONE BROKEN") and event != previous:
                        message = (f'{event}: {z["symbol"]} ({z["timeframe"]} {z["pattern"]}) | '
                                   f'Price ₹{px:.2f} | Demand ₹{z["zone_low"]:.2f}–₹{z["zone_high"]:.2f} | '
                                   f'Score {z["score"]}/100')
                        log_alert(z["symbol"], z["timeframe"], event, px, z["zone_low"], z["zone_high"], z["score"], message)
                        new_events.append(message)
                        if tg_token and tg_chat:
                            send_telegram(tg_token, tg_chat, message)
                    st.session_state.last_event[key] = event
                if new_events:
                    st.success(f"{len(new_events)} new alert(s) logged.")
                    for msg in new_events:
                        st.write("🔔 " + msg)
                else:
                    st.info("Refresh ke waqt koi naya zone-state transition nahi mila.")
            except Exception as e:
                st.error(f"Live quote error: {e}")

    if st.session_state.zones:
        live_rows = []
        for z in st.session_state.zones:
            px = st.session_state.last_ltp.get(z["symbol"], z.get("scan_price"))
            event = evaluate_zone(z["zone_low"], z["zone_high"], px, near_pct) if px else "PRICE UNAVAILABLE"
            live_rows.append({**z, "ltp": px, "live_status": event})
        live_df = pd.DataFrame(live_rows)
        st.dataframe(live_df, use_container_width=True, hide_index=True)
        st.caption("Note: LTP is live only after a successful manual refresh or auto-refresh page cycle. This prototype polls quotes; it is not a continuous WebSocket daemon.")
    else:
        st.info("Abhi zones loaded nahi hain. Zone Scan tab se scan karein.")

with tabs[1]:
    st.subheader("Scan Nifty 500 demand zones")
    st.write("Historical candles se Daily/Weekly zones identify honge; current LTP se near/entered status evaluate hoga.")
    max_symbols = st.number_input("Maximum symbols this run (API/rate-limit safety)", min_value=1, max_value=500, value=min(100, max(1, len(symbols))), step=25)
    if st.button("▶ Run zone scan", type="primary"):
        if use_demo:
            sample = pd.read_csv(os.path.join(os.path.dirname(__file__), "data", "sample_ohlcv.csv"), parse_dates=["Date"])
            demo_symbols = sample["Symbol"].unique().tolist()
            scan_symbols = demo_symbols
            instrument_map = {}
            kite = None
        else:
            if not symbols:
                st.error("Nifty 500 symbols CSV upload karein, ya demo checkbox use karein.")
                st.stop()
            if not (api_key and access_token):
                st.error("Live scan ke liye Kite API key aur access token chahiye.")
                st.stop()
            scan_symbols = symbols[:int(max_symbols)]
            try:
                kite = connect_kite(api_key, access_token)
                instrument_map = load_nse_instruments(kite)
            except Exception as e:
                st.error(f"Kite connection/instrument list failed: {e}")
                st.stop()

        all_zones, errors = [], []
        progress = st.progress(0)
        status = st.empty()
        for idx, sym in enumerate(scan_symbols):
            try:
                if use_demo:
                    raw = sample[sample["Symbol"].str.upper() == sym.upper()].rename(
                        columns={"Date":"date","Open":"open","High":"high","Low":"low","Close":"close","Volume":"volume"})
                    if raw.empty:
                        continue
                    ltp = float(raw["close"].iloc[-1])
                else:
                    token = instrument_map.get(sym)
                    if token is None:
                        errors.append(f"{sym}: symbol not found in NSE instrument list")
                        continue
                    raw = fetch_daily_history(kite, token, lookback_days=750)
                    ltp = None
                for tf in timeframes:
                    zones = build_zones(sym, raw, timeframe=tf, max_age_bars=int(freshness_days))
                    for z in zones:
                        z["scan_price"] = ltp
                        z["data_status"] = "SYNTHETIC DEMO" if use_demo else "KITE HISTORICAL"
                        if z["score"] >= min_score:
                            if ltp is not None:
                                z["live_status"] = evaluate_zone(z["zone_low"], z["zone_high"], ltp, near_pct)
                            all_zones.append(z)
            except Exception as e:
                errors.append(f"{sym}: {e}")
            progress.progress((idx + 1) / max(1, len(scan_symbols)))
            status.write(f"Processed {idx+1}/{len(scan_symbols)} symbols")
            if not use_demo:
                time.sleep(0.35)  # conservative pacing for historical requests

        # Keep latest zone per symbol/timeframe/pattern
        if all_zones:
            all_zones = sorted(all_zones, key=lambda x: (x["symbol"], x["timeframe"], x["score"]), reverse=True)
            dedup = {}
            for z in all_zones:
                key = (z["symbol"], z["timeframe"])
                if key not in dedup:
                    dedup[key] = z
            all_zones = list(dedup.values())
        st.session_state.zones = all_zones
        st.session_state.last_ltp = {z["symbol"]: z["scan_price"] for z in all_zones if z.get("scan_price") is not None}
        if all_zones:
            out = pd.DataFrame(all_zones).sort_values(["score"], ascending=False)
            st.success(f"{len(out)} candidate zones found.")
            st.dataframe(out, use_container_width=True, hide_index=True)
            st.download_button("Download zones CSV", out.to_csv(index=False).encode("utf-8"), "htf_demand_zones.csv", "text/csv")
        else:
            st.warning("Current filters par koi zone nahi mila. Score threshold kam karein ya candle history/universe check karein.")
        if errors:
            with st.expander(f"Skipped/errors ({len(errors)})"):
                st.text("\n".join(errors[:200]))

with tabs[2]:
    st.subheader("Alert history")
    hist = get_alerts(limit=250)
    if hist:
        st.dataframe(pd.DataFrame(hist), use_container_width=True, hide_index=True)
        st.download_button("Download alert history", pd.DataFrame(hist).to_csv(index=False).encode("utf-8"), "demand_alert_history.csv", "text/csv")
    else:
        st.info("Abhi alerts log nahi hue.")

with tabs[3]:
    st.subheader("Setup guide")
    st.markdown("""
1. **Python 3.10+** install karein.
2. ZIP extract karke terminal mein project folder open karein.
3. Run:
   ```bash
   pip install -r requirements.txt
   streamlit run app.py
   ```
4. `Nifty 500` constituent list CSV upload karein; first column ka naam `symbol` rakhein (NSE trading symbols).
5. Zerodha developer account mein Kite Connect app banayein. Live/historical market data ke liye paid Connect plan required ho sakta hai; current terms Zerodha par verify karein.
6. API key aur session access token app sidebar mein enter karein. Secrets ko source code ya public repo mein kabhi na rakhein.
7. Zone Scan tab mein scan karein, phir Live Monitor mein prices refresh karke alerts check karein.

**Platform note:** Web app responsive browser mein chal sakta hai. Android ke liye abhi included wrapper guide ek hosted web app ko Android WebView mein package karne ka starting point hai; signed APK build/publish karna is ZIP se automatically nahi hota.
""")
    st.markdown("**Risk note:** score is a heuristic, not a win probability. Inspect chart manually and backtest before using real capital.")
